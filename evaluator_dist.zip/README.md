evaluator
=========

### Installation details -

*your classpath variable name must be "EVALUATOR"*

*classpath contains path of bin folder*

*example = "D:\projects\evaluator"*
