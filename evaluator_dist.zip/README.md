evaluator
=========

### Installation details -

*your classpath variable name must be "EVALUATOR_HOME"*

*classpath contains path of bin folder*

*example = "D:\projects\evaluator\evaluator_dist"*

### Running Program-

1) Release 0.1
*sh evaluator.sh "expression"*
** for ex = sh evaluator.sh "2 + 3"

steps----
1)product can perform only addition of two operands
2)expression must contain space between operands and operator
3)if space is not present,it will give 0